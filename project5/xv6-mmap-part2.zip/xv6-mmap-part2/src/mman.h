
// Protection bits 
#define PROT_WRITE      1
// Flags 
#define MAP_ANONYMOUS   0
#define MAP_FILE        1
